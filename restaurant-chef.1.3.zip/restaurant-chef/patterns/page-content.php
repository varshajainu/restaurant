<?php
/**
 * Title: Page Content
 * Slug: restaurant-chef/page-content
 * Categories: restaurant-chef, page-content
 */
?>

<!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:post-content /--></div>
<!-- /wp:group -->